%% IRLP(VAR)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% VAR_LP_Toolkit Ver. 1.0
% Dong-jae Jung, Bank of Korea
% djjeong@bok.or.kr
% July. 2022
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Model = IRLP(Model, optLP)

%% 0. Define vars.
ENDO = Model.ENDO; 
Y = Model.Y;
nvar = Model.nvar;
% nlags = Model.nlags;

if isfield(Model, 'Exo')
    Xnotrend = cat(2, ENDO, Model.Exo);
else
    Xnotrend = ENDO;
end


%% 1. Option for SE type
if ~isfield(optLP, 'SEtype')
    optLP.SEtype = 'HAC';    
    disp('HAC estimator with the automatic bandwidth selection procedure by Newey & West(1994) is used for LP')
end

varargin_{1} = optLP.SEtype;
switch optLP.SEtype
    case 'HAC'        
        if isfield(optLP, 'HAC_lag')
            varargin_{2} = optLP.HAC_lag;
        end
    case 'cluster'
        varargin_{2} = optLP.clusterID;
        disp('Cluster ID is required for SEtype cluster')
end

%% Impulse Responses
if ~isfield(optLP, 'ortho')
    optLP.ortho = 0;         % Default : Non-orthogonalized IR
end
Ortho = optLP.ortho;
if ~isfield(optLP, 'unitshock')
    optLP.unitshock = 1;     % Default : Unit shock
end

% % If orthogonalized IR, use VAR structure
% if Ortho == 1
%     Model = VAR_ols(Model);
%     % if P not given, assume recursive ordering
%     if ~isfield(Model, 'P')
%         [P, flag] = chol(Model.Sigma, 'lower');
%         Model.P = P;
%     end
%     Pnorm = Model.P/diag(diag(Model.P));
%     Model.Pnorm = Pnorm;  % Normalization
%     if optLP.unitshock
%         PP = Model.P;
%     else
%         PP = Model.Pnorm;
%     end
% elseif Ortho ==0
%     if optLP.unitshock
%         PP = eye(nvar,nvar);
%     else
%         PP = diag(sqrt(diag(Model.Sigma)));
%     end
% else
%     error('optCI.ortho must be 1 or 0')
% end

if Ortho == 1
    if optLP.unitshock
        PP = Model.Pnorm;
    else
        PP = Model.P;
    end
elseif Ortho ==0
    if optLP.unitshock
        PP = eye(nvar,nvar);
    else
        PP = diag(sqrt(diag(Model.Sigma)));
    end
else
    error('optCI.ortho must be 1 or 0')
end

% 2. Response vars. (if resvar not given, responses of all the variables
% are calculated.)
if ~isfield(optLP, 'resvar')
    resvar = Model.varnamesX;    
    optLP.resvar = resvar;
end

residx = find(strcmp(Model.varnamesX, resvar));
allidx = 1:nvar;

IR = zeros(optLP.IRhor, length(residx), nvar);
SE = zeros(optLP.IRhor, length(residx), nvar);
IR(1,:,:) = PP(residx,:);

for v = 1:length(residx)
    vidx = allidx(residx(v));
    Yv = Y(:,vidx);

    for t =1:optLP.IRhor-1
        OLS = makeOLS(Yv(t:end,:),Xnotrend(1:end-t+1,:), Model.trend, varargin_{:});
        IR(t+1,v,:) = OLS.beta( 1:nvar );
        SE(t+1,v,:) = OLS.SEbeta( 1:nvar );
    end
end
for t =2:optLP.IRhor
    IR(t,:,:) = squeeze(IR(t,:,:)) * PP;
end

%% Confidence Interval

if ~strcmp(optLP.CImethod, 'None')
CIlevel_half = (100-optLP.CIlevel)/100/2;
% thre = [CIlevel_half 1-CIlevel_half];
% INF = IR(:);  SUP = IR(:);
% SEvec = SE(:);
% for i = 1:length(SEvec)
modi = norminv(CIlevel_half, 0, SE);
modi(1,:,:) = 0;
CI.INF = IR + modi;
CI.SUP = IR - modi;

Model.CI = CI;
end
%% return
Model.IR = IR;
Model.optIR = optLP;
% Model.optLP = optLP;
% if isfield(Model, 'CI')
%     Model = rmfield(Model, 'CI');
% end
end

