function xT = dataTransform(x, tcode, frequency)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    Transform data according to tcode
%       1. log
%       2. log-first differencing *100
%       3. log-second differencing *100
%       4. level-first differencing
%       5. level-YoY differencing
%       6. log-YoY differencing *100
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if exist('frequency', 'var')
    switch frequency
        case {'Q', 'q'}
            ff = 4;
        case {'M', 'm'}
            ff = 12;
        case {'Y', 'y'}
            ff = 1;
    end
end

switch tcode
    case 1
        xT = log(x);
        xT(x<=0) = NaN;
    case 2
        xT = log(x) *100;
        xT(x<=0) = NaN;
        xT(2:end) = xT(2:end) - xT(1:end-1);
        xT(1) = NaN;
    case 3
        xT = log(xT) *100;
        xT(x<=0) = NaN;
        for i = 1:2
            xT(2:end) = xT(2:end) - xT(1:end-1);
            xT(i) = NaN;
        end
    case 4
        xT = x;
        xT(2:end) = xT(2:end) - xT(1:end-1);
        xT(1) = NaN;
    case 5
        xT = x;
        xT(ff+1:end) = xT(ff+1:end) - xT(1:end-ff);
        xT(1:ff) = NaN;
    case 6
        xT = log(x) *100;
        xT(ff+1:end) = xT(ff+1:end) - xT(1:end-ff);
        xT(1:ff) = NaN;
    otherwise
        xT = x;
end

end