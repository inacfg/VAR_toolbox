function VAR = IRBVAR_SIGN(VAR, optIR)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Return Impulse Responses and confidence interval by Baysian estimation
% Adopted into the toolbox based on Koop & Korobilis(2009)

% Possible optIR.prior : 
%       1. 'Diffuse Prior'                       
%       2. 'Natural Conjugate Prior'
%       3. 'Minnesota Prior'
%       4. 'Independent Normal-Wishart Prior'
%
% optIR.SRmethod can be chosen from
%       1. 'Pure'
%       2. 'Penalty'
%       ,following to Uhlig(2005)
%
% Penalty function(fnPenalty) is defined below,
% as a linear function multiplying 100 to the opposite sign.
% You can Modify it to what you want.
%
% VAR_LP_Toolkit Ver. 1.0 (2022)
% Dong-jae Jung, Bank of Korea
% djjeong@bok.or.kr
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Uncertainty associated with Structural Identification
if ~isfield(optIR, 'SRmethod')
    optIR.SRmethod = 'Pure';
end
% If you want to jointly consider this uncertainty, give optIR.P_uncertainty =1
if ~isfield(optIR, 'nburn')
    optIR.nburn = 2000;
end
if ~isfield(optIR, 'ndraw')
    optIR.ndraw = 200;
end
if ~isfield(optIR, 'nrotate')
    optIR.nrotate = optIR.ndraw;
end

if ~isfield(optIR, 'prior')
    optIR.prior = 4;
    disp('Assuming the Independent Normal-Wishart Prior')
end

%% Define parameters
optIR.CImethod = 'BVAR';
prior = optIR.prior;

% reduceVAR results
BETAols = VAR.Beta; % This is the matrix of regression coefficients
betaols = VAR.beta;         % This is the vector of parameters, i.e. it holds
                          % that a_OLS = vec(A_OLS)
SSEols = VAR.SSE;   % Sum of squared errors
SIGMAols = VAR.Sigma;
nvar = VAR.nvar;
nlags = VAR.nlags;
Nx = VAR.Nx;
T = VAR.T;
Y = VAR.Y;
X = VAR.X;
Z = kron(eye(nvar),X);

% set up
ndraw = optIR.ndraw;         % Final number of draws to save
nrotate = optIR.nrotate;         % Maximum number of draws
nburn = optIR.nburn;         % Draws to discard (burn-in)
switch optIR.SRmethod
    case 'Pure'        
        ntot = ndraw*nrotate;
    case 'Penalty'
        ntot = ndraw;
end
% For models using analytical results, there are no convergence issues (You
% are not adviced to change the next 3 lines)
if prior ==1 || prior == 2 || prior == 3
    nburn = 0*nburn;
    optIR.nburn = nburn;
end

% Initialize Bayesian posterior parameters using OLS values
VARi = VAR;
betai = betaols;     % This is the single draw from the posterior of alpha
BETAi = BETAols;     % This is the single draw from the posterior of ALPHA
SSEi = SSEols;   % This is the SSE based on each draw of ALPHA
SIGMAi = SIGMAols; % This is the single draw from the posterior of SIGMA

% Storage space for posterior draws
beta_draws = zeros(ntot,Nx,nvar);   % save draws of alpha
BETA_draws = zeros(ntot,Nx,nvar);   % save draws of alpha
SIGMA_draws = zeros(ntot,nvar,nvar);   % save draws of ALPHA

IR_draws = zeros(ntot, optIR.IRhor, nvar, nvar);

% Prior
n = Nx*nvar; % Total number of parameters (size of vector alpha)
a_prior = 0*ones(n,1);   %<---- prior mean of alpha (parameter vector)
V_prior = 10*eye(n);     %<---- prior variance of alpha

% Hyperparameters on inv(SIGMA) ~ W(v_prior,inv(S_prior))
v_prior = nvar+1;             %<---- prior Degrees of Freedom (DoF) of SIGMA
S_prior = eye(nvar);            %<---- prior scale of SIGMA

%% SIGN restriction Setup
SIGN = VAR.SIGN;
% IRhor_SR = find(squeeze(sum(sum(abs(SIGN), 1),2)), 1, 'last'); 
SIGNflat = SIGN(SIGN~=0);

optIRi = optIR;
% optIRi.IRhor = IRhor_SR;
optIRi.ortho = 1;
optIRi.unitshock = 1;    
optIRi.CImethod = 'None'; 

%%
%========================== Start Sampling ================================
%==========================================================================
tic;
% disp('Number of iterations');
ww   = waitbar(0,'Bayesian estimation is started','Name','Bayesian estimation progress'); %, 'CreateCancelBtn','setappdata(gcbf,''canceling'',1)');

% Define non-loop variables at first
EE = [eye(nvar) ; zeros(nvar*(nlags-1), nvar)];
options = optimoptions(@fminunc,'Display','off','Algorithm','quasi-newton');

irep = 1; isave =1; nonconv_count=0; nonconv_i_tag =0;
while irep < ntot + nburn
      
%     if mod(irep,it_print) == 0 % print iterations
%         disp(irep);
%         toc;
%     end
    
    %--------- Draw ALPHA and SIGMA with Diffuse Prior
    if prior == 1
        % Posterior of alpha|SIGMA,Data ~ Normal
        V_post = kron(SIGMAi,inv(X'*X));
        betai = betaols + chol(V_post)'*randn(Nx*nvar,1);% Draw alpha
        BETAi = reshape(betai,Nx,nvar); % Create draw of ALPHA       
        
        % Posterior of SIGMA|Data ~ iW(SSE_Gibbs,T-Nx) 
        SIGMAi = inv(wish(inv(SSEi),T-Nx));% Draw SIGMA
        
    %--------- Draw ALPHA and SIGMA with Minnesota Prior
    elseif prior == 2
        %Draw ALPHA
        for i = 1:nvar
            V_post = inv( inv(V_prior((i-1)*Nx+1:i*Nx,(i-1)*Nx+1:i*Nx)) + inv(SIGMAi(i,i))*X'*X );
            a_post = V_post*(inv(V_prior((i-1)*Nx+1:i*Nx,(i-1)*Nx+1:i*Nx))*a_prior((i-1)*Nx+1:i*Nx,1) + inv(SIGMAi(i,i))*X'*Y(:,i));
            betai((i-1)*Nx+1:i*Nx,1) = a_post + chol(V_post)'*randn(Nx,1); % Draw alpha
        end
        BETAi = reshape(betai,Nx,nvar); % Create draw in terms of ALPHA
        
        % SIGMA in this case is a known matrix, whose form is decided in
        % the prior (see prior_hyper.nvar)
        
    %--------- Draw ALPHA and SIGMA with Normal-Wishart Prior
    elseif prior == 3
        % ******Get all the required quantities for the posteriors       
        V_post = inv( inv(V_prior) + X'*X );
        A_post = V_post*(inv(V_prior)*A_prior + X'*X*BETAols);
        a_post = A_post(:);
    
        S_post = SSEols + S_prior + BETAols'*X'*X*BETAols + A_prior'*inv(V_prior)*A_prior - A_post'*(inv(V_prior) + X'*X)*A_post;
        v_post = T + v_prior;
    
        % This is the covariance for the posterior density of alpha
        COV = kron(SIGMAi,V_post);
    
        % Posterior of alpha|SIGMA,Data ~ Normal
        betai = a_post + chol(COV)'*randn(Nx*nvar,1);  % Draw alpha
        BETAi = reshape(betai,Nx,nvar); % Draw of ALPHA
        
        % Posterior of SIGMA|ALPHA,Data ~ iW(inv(S_post),v_post)
        SIGMAi = inv(wish(inv(S_post),v_post));% Draw SIGMA
        
    %--------- Draw ALPHA and SIGMA with Independent Normal-Wishart Prior
    elseif prior == 4
                    
        VARIANCE = kron(inv(SIGMAi),eye(T));
        V_post = inv(inv(V_prior) + Z'*VARIANCE*Z);
        a_post = V_post*(inv(V_prior)*a_prior + Z'*VARIANCE*Y(:));
        betai = a_post + chol(V_post)'*randn(n,1); % Draw of alpha
        
        BETAi = reshape(betai,Nx,nvar); % Draw of ALPHA
        
        % Posterior of SIGMA|ALPHA,Data ~ iW(inv(S_post),v_post)
        v_post = T + v_prior;
        S_post = S_prior + (Y - X*BETAi)'*(Y - X*BETAi);
        SIGMAinv = chol(inv(S_post))'*randn(nvar,v_post);
        SIGMAinv = SIGMAinv*SIGMAinv';
        SIGMAi = inv(SIGMAinv);% Draw SIGMA
    end
    % =============Estimation ends here
    
    % ****************************|Predictions, Responses, etc|***************************
    if irep > nburn    
        waitbar((irep-nburn)/ntot,ww,sprintf('%.3f percent complete',(irep-nburn)/ntot*100));   
        %=========IMPULSE RESPONSES:
%         VAR = reducedVAR(VAR);
        VARi.Beta = BETAi;
        VARi.Sigma = SIGMAi;
        [Pchol, flag] = chol(SIGMAi, 'lower');
        Pnorm = Pchol/diag(diag(Pchol));
        
        switch optIR.SRmethod
            case 'Pure'        
                for dd = 1:nrotate
                    W = randn(nvar);
                    [Q,~] = qr(W);
                    Q = Q*diag(sign(diag(Q)));
                    VARi.P = Pnorm*Q';  % Impulse matrix

                    VARi = IRVAR(VARi, optIRi);
                    % Check sign
                    IRi = VARi.IR;            
        %             IRsign = sign(IRi(1:IRhor_SR, :,:));
                    IRsign = sign(IRi);
                    IRflat = IRsign(SIGN~=0);
                    if (sum(IRflat ~= SIGNflat) ==0)
                        IR_draws(isave,:,:,:) = VARi.IR;  
                        %----- Save draws of the parameters
        %                 beta_draws(isave,:) = betai;
                        BETA_draws(isave,:,:) = BETAi;
                        SIGMA_draws(isave,:,:) = SIGMAi;
                        isave = isave+1;
                    elseif (sum(-1*IRflat ~= SIGNflat) ==0)
                        IR_draws(isave,:,:,:) = -1*VARi.IR;  
                        %----- Save draws of the parameters
        %                 beta_draws(isave,:) = betai;
                        BETA_draws(isave,:,:) = BETAi;
                        SIGMA_draws(isave,:,:) = SIGMAi;
                        isave = isave+1;
                    end     
                    irep = irep+1; 
                end
            case 'Penalty'             
                SRbyshock = squeeze(sum(abs(SIGN), 2)); % IRhor * nshock
                IRi = zeros(optIR.IRhor, nvar, nvar);
                for shock = 1:nvar
                    SRhor = find(squeeze(SRbyshock(:,shock)), 1, 'last'); 
                    if ~isempty(SRhor)
                        Compi = [BETAi(1:nvar*nlags,:)'; eye(nvar*(nlags-1)) zeros(nvar*(nlags-1),nvar)];
                        SIGNs = squeeze(SIGN(:,:,shock)); 

                        fnTP = @(x) totalPenalty(x, Pnorm, Compi, EE, SIGNs, SRhor);       
                        nmin = 1;
                        exitflag = -1;
                        while (nmin<4) && (exitflag<=0)
                            paraX = randn(1,nvar-1);   
                            [para,fval,exitflag,output] = fminunc(fnTP,paraX,options);
    %                     tp = totalPenalty(paraX, Pnorm, Compi, EE, SIGNs, SRhor);
                            nmin = nmin+1;
                        end
                        
                        if (nmin==4) && (exitflag<=0)
                            nonconv_i_tag = 1;
                            nonconv_count = nonconv_count+1;
                            break
                        end

                        paraf = stereoProj(para);
                        Impulse = Pnorm*paraf';  % Impulse vector
                        IRi(1,:,shock) = Impulse;
                        PSI = eye(size(Compi));
                        for h = 2:optIR.IRhor
                            PSI = Compi*PSI;
                            IRi(h,:,shock) = EE'*PSI*EE*Impulse;
                        end
                    end
                end
                if nonconv_i_tag ==0
                    IR_draws(isave,:,:,:) = IRi;  
    %                 beta_draws(isave,:) = betai;
                    BETA_draws(isave,:,:) = BETAi;
                    SIGMA_draws(isave,:,:) = SIGMAi;
                    isave = isave+1;
                    irep = irep+1; 
                else
                    nonconv_i_tag =0;
                end
        end                    
        
    else
        irep = irep+1;        

    end % end saving results
       
end %end the main Gibbs for loop
delete(ww);

if strcmp(optIR.SRmethod,'Pure')
    isave = isave -1;
    disp(['Total number of success draws : ' num2str(isave)])
    disp(['Success ratio : ' num2str(isave/ntot)])

    if isave >2
        IR_draws = IR_draws(1:isave,:,:,:);
    %     beta_draws = beta_draws(1:isave,:,:,:);
        BETA_draws = BETA_draws(1:isave,:,:,:);
        SIGMA_draws = SIGMA_draws(1:isave,:,:,:);
    end    
elseif strcmp(optIR.SRmethod,'Penalty')    
    disp(['Total number of non-converging draw occured : ' num2str(nonconv_count)])
end
%====================== End Sampling Posteriors ===========================

% Impulse responses
cl = round((100-optIR.CIlevel)/2);
VAR.CI.INF = squeeze(prctile(IR_draws, cl));
VAR.CI.SUP = squeeze(prctile(IR_draws, 100-cl));
VAR.CI.MED = squeeze(prctile(IR_draws, 50));
VAR.CI.MEAN = squeeze(mean(IR_draws, 1));
VAR.IR = VAR.CI.MED;  % set as median values
VAR.P = squeeze(VAR.IR(1,:,:));  % set as median values
VAR.IRdraws = IR_draws;

%Posterior mean of parameters:
VAR.Beta = squeeze(mean(BETA_draws,1)); %posterior mean of ALPHA
VAR.Sigma = squeeze(mean(SIGMA_draws,1)); %posterior mean of SIGMA

%Posterior standard deviations of parameters:
VAR.Beta_std = squeeze(std(BETA_draws,1)); %posterior std of ALPHA
VAR.Sigma_std = squeeze(std(SIGMA_draws,1)); %posterior std of SIGMA
%or you can use 'ALPHA_COV = cov(alpha_draws,1);

% Save draws
VAR.BVARdraws.Beta = BETA_draws;
VAR.BVARdraws.Sigma = SIGMA_draws;
VAR.BVARdraws.P = squeeze(IR_draws(:,1,:,:));

VAR.res = VAR.Y - VAR.X*VAR.Beta;
VAR.SSE = (VAR.res'*VAR.res);
VAR.beta = VAR.Beta(:);

VAR.Comp = [VAR.Beta(1:VAR.nvar*VAR.nlags,:)'; eye(VAR.nvar*(VAR.nlags-1)) zeros(VAR.nvar*(VAR.nlags-1),VAR.nvar)];
VAR.maxEig = max(abs(eig(VAR.Comp)));


VAR.Beta_ols = BETAols;
VAR.beta_ols = betaols;
VAR.SSE_ols = SSEols;
VAR.Sigma_ols = SIGMAols;

VAR.optIR = optIR;

end

function p = fnPenalty(x)
p = x;
pos = (x>=0);
p(pos) = 100*p(pos);
end

function para = stereoProj(paraX) % paraX : row vector
S2 = paraX*paraX';
para = [(S2-1)/(S2+1) 2*paraX/(S2+1)];
end

function tp = totalPenalty(paraX, Pnorm, Compi, EE, SIGNs, SRhor)
para = stereoProj(paraX);
Impulse = Pnorm*para';  % Impulse vector
IR = zeros(size(SIGNs));
IR(1,:) = Impulse;

PSI = eye(size(Compi));
if SRhor>1
    for h = 2:SRhor
        PSI = Compi*PSI;
        IR(h,:) = EE'*PSI*EE*Impulse;
    end
end

IRval = IR.*(-SIGNs);
penalty = fnPenalty(IRval);
tp = sum(reshape(penalty,1,[]));
end
