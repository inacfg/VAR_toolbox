function VAR = IRBVAR(VAR, optIR)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Return Impulse Responses and confidence interval by Baysian estimation
% Adopted into the toolbox based on Koop & Korobilis(2009)

% Possible optIR.prior : 
%       1. 'Diffuse Prior'                       
%       2. 'Natural Conjugate Prior'
%       3. 'Minnesota Prior'
%       4. 'Independent Normal-Wishart Prior'
%
% If you want to jointly consider uncertainty associated structural identification parameters, then
% set P_uncertainty = 1
% (Default) P_uncertainty == 1 and assuming recursive ordering
%
% VAR_LP_Toolkit Ver. 1.0
% Dong-jae Jung, Bank of Korea
% djjeong@bok.or.kr
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if ~isfield(optIR, 'P_uncertainty')  % (Default) P_uncertainty == 1 and assuming recursive ordering
    optIR.P_uncertainty = 1; 
    VAR.B = NaN(VAR.nvar, VAR.nvar); VAR.B = tril(VAR.B);
    VAR.A = eye(VAR.nvar);
elseif optIR.P_uncertainty == 1
    if isfield(VAR, 'P')
        if sum(reshape((VAR.P~=0) - tril(true(VAR.nvar,VAR.nvar)), 1,[]))==0  % if given P is lower triangle
            VAR = rmfield(VAR, 'P');
            VAR.B = NaN(VAR.nvar, VAR.nvar); VAR.B = tril(VAR.B);
            VAR.A = eye(VAR.nvar);
        else
            % optIR.P_uncertainty = 1 is possible for Non-recursive P, but
            % currently this is offed because of computational burden
            disp('Non-recursive P is given. This makes the optIR.P_uncertainty option be turned off.')
            optIR.P_uncertainty = 0;
        end
    end
    if isfield(VAR, 'Pnorm')
        VAR = rmfield(VAR, 'Pnorm');
    end
end

if ~isfield(optIR, 'nsave')
    optIR.nsave = 10000;
end
if ~isfield(optIR, 'nburn')
    optIR.nsave = 2000;
end

if ~isfield(optIR, 'prior')
    optIR.prior = 4;
    disp('Assuming the Independent Normal-Wishart Prior')
end

%% Define parameters
optIR.CImethod = 'None';
prior = optIR.prior;

% reduceVAR results
BETAols = VAR.Beta; % This is the matrix of regression coefficients
betaols = VAR.beta;         % This is the vector of parameters, i.e. it holds
                          % that a_OLS = vec(A_OLS)
SSEols = VAR.SSE;   % Sum of squared errors
SIGMAols = VAR.Sigma;
nvar = VAR.nvar;
nlags = VAR.nlags;
Nx = VAR.Nx;
T = VAR.T;
Y = VAR.Y;
X = VAR.X;
Z = kron(eye(nvar),X);

% set up
nsave = optIR.nsave;         % Final number of draws to save
nburn = optIR.nburn;         % Draws to discard (burn-in)
% For models using analytical results, there are no convergence issues (You
% are not adviced to change the next 3 lines)
if prior ==1 || prior == 2 || prior == 3
    nburn = 0*nburn;
    optIR.nburn = nburn;
end
ntot = nsave + nburn;  % Total number of draws

% Initialize Bayesian posterior parameters using OLS values
VARi = VAR;
betai = betaols;     % This is the single draw from the posterior of alpha
BETAi = BETAols;     % This is the single draw from the posterior of ALPHA
SSEi = SSEols;   % This is the SSE based on each draw of ALPHA
SIGMAi = SIGMAols; % This is the single draw from the posterior of SIGMA

% Storage space for posterior draws
beta_draws = zeros(nsave,Nx,nvar);   % save draws of alpha
BETA_draws = zeros(nsave,Nx,nvar);   % save draws of alpha
SIGMA_draws = zeros(nsave,nvar,nvar);   % save draws of ALPHA
if optIR.ortho==1
    P_draws = zeros(nsave,nvar,nvar);
end

IR_draws = zeros(nsave, optIR.IRhor, nvar, nvar);

% Prior
n = Nx*nvar; % Total number of parameters (size of vector alpha)
a_prior = 0*ones(n,1);   %<---- prior mean of alpha (parameter vector)
V_prior = 10*eye(n);     %<---- prior variance of alpha

% Hyperparameters on inv(SIGMA) ~ W(v_prior,inv(S_prior))
v_prior = nvar+1;             %<---- prior Degrees of Freedom (DoF) of SIGMA
S_prior = eye(nvar);            %<---- prior scale of SIGMA


%========================== Start Sampling ================================
%==========================================================================
tic;
% disp('Number of iterations');
ww   = waitbar(0,'Bayesian estimation is started','Name','Bayesian estimation progress');
for irep = 1:ntot  %Start the Gibbs "loop"
      
%     if mod(irep,it_print) == 0 % print iterations
%         disp(irep);
%         toc;
%     end
    
    %--------- Draw ALPHA and SIGMA with Diffuse Prior
    if prior == 1
        % Posterior of alpha|SIGMA,Data ~ Normal
        V_post = kron(SIGMAi,inv(X'*X));
        betai = betaols + chol(V_post)'*randn(Nx*nvar,1);% Draw alpha
        BETAi = reshape(betai,Nx,nvar); % Create draw of ALPHA       
        
        % Posterior of SIGMA|Data ~ iW(SSE_Gibbs,T-Nx) 
        SIGMAi = inv(wish(inv(SSEi),T-Nx));% Draw SIGMA
        
    %--------- Draw ALPHA and SIGMA with Minnesota Prior
    elseif prior == 2
        %Draw ALPHA
        for i = 1:nvar
            V_post = inv( inv(V_prior((i-1)*Nx+1:i*Nx,(i-1)*Nx+1:i*Nx)) + inv(SIGMAi(i,i))*X'*X );
            a_post = V_post*(inv(V_prior((i-1)*Nx+1:i*Nx,(i-1)*Nx+1:i*Nx))*a_prior((i-1)*Nx+1:i*Nx,1) + inv(SIGMAi(i,i))*X'*Y(:,i));
            betai((i-1)*Nx+1:i*Nx,1) = a_post + chol(V_post)'*randn(Nx,1); % Draw alpha
        end
        BETAi = reshape(betai,Nx,nvar); % Create draw in terms of ALPHA
        
        % SIGMA in this case is a known matrix, whose form is decided in
        % the prior (see prior_hyper.nvar)
        
    %--------- Draw ALPHA and SIGMA with Normal-Wishart Prior
    elseif prior == 3
        % ******Get all the required quantities for the posteriors       
        V_post = inv( inv(V_prior) + X'*X );
        A_post = V_post*(inv(V_prior)*A_prior + X'*X*BETAols);
        a_post = A_post(:);
    
        S_post = SSEols + S_prior + BETAols'*X'*X*BETAols + A_prior'*inv(V_prior)*A_prior - A_post'*(inv(V_prior) + X'*X)*A_post;
        v_post = T + v_prior;
    
        % This is the covariance for the posterior density of alpha
        COV = kron(SIGMAi,V_post);
    
        % Posterior of alpha|SIGMA,Data ~ Normal
        betai = a_post + chol(COV)'*randn(Nx*nvar,1);  % Draw alpha
        BETAi = reshape(betai,Nx,nvar); % Draw of ALPHA
        
        % Posterior of SIGMA|ALPHA,Data ~ iW(inv(S_post),v_post)
        SIGMAi = inv(wish(inv(S_post),v_post));% Draw SIGMA
        
    %--------- Draw ALPHA and SIGMA with Independent Normal-Wishart Prior
    elseif prior == 4
                    
        VARIANCE = kron(inv(SIGMAi),eye(T));
        V_post = inv(inv(V_prior) + Z'*VARIANCE*Z);
        a_post = V_post*(inv(V_prior)*a_prior + Z'*VARIANCE*Y(:));
        betai = a_post + chol(V_post)'*randn(n,1); % Draw of alpha
        
        BETAi = reshape(betai,Nx,nvar); % Draw of ALPHA
        
        % Posterior of SIGMA|ALPHA,Data ~ iW(inv(S_post),v_post)
        v_post = T + v_prior;
        S_post = S_prior + (Y - X*BETAi)'*(Y - X*BETAi);
        SIGMAinv = chol(inv(S_post))'*randn(nvar,v_post);
        SIGMAinv = SIGMAinv*SIGMAinv';
        SIGMAi = inv(SIGMAinv);% Draw SIGMA
    end
    % =============Estimation ends here
    
    % ****************************|Predictions, Responses, etc|***************************
    if irep > nburn    
        isave = irep-nburn;
        waitbar(isave/nsave,ww,sprintf('%.3f percent complete',isave/nsave*100));   
        %=========IMPULSE RESPONSES:
        if (optIR.P_uncertainty ==1) && (optIR.ortho==1)
            VARi = VAR;  % Reset VARi (no P & Pnorm)
            VARi.Beta = BETAi;
            VARi.Sigma = SIGMAi;
%             VARi.para_ini = VAR.para;
            VARi.Comp = [BETAi(1:nvar*nlags,:)'; eye(nvar*(nlags-1)) zeros(nvar*(nlags-1),nvar)];
%             VARi.maxEig = max(abs(eig(VARi.Comp)));
            VARi = structuralIR(VARi, optIR);
        else            
            VARi.Beta = BETAi;
            VARi.Sigma = SIGMAi;
            VARi.Comp = [BETAi(1:nvar*nlags,:)'; eye(nvar*(nlags-1)) zeros(nvar*(nlags-1),nvar)];
%             VARi.maxEig = max(abs(eig(VARi.Comp)));
        end

        VARi = IRVAR(VARi, optIR);
        IR_draws(isave,:,:,:) = VARi.IR;  
               
        %----- Save draws of the parameters
        beta_draws(isave,:) = betai;
        BETA_draws(isave,:,:) = BETAi;
        SIGMA_draws(isave,:,:) = SIGMAi;
        if optIR.ortho==1
            P_draws(isave,:,:) = VARi.P;
        end

    end % end saving results
       
end %end the main Gibbs for loop
delete(ww);
%====================== End Sampling Posteriors ===========================

% Impulse responses
cl = round((100-optIR.CIlevel)/2);
VAR.CI.INF = squeeze(prctile(IR_draws, cl));
VAR.CI.SUP = squeeze(prctile(IR_draws, 100-cl));
VAR.CI.MED = squeeze(prctile(IR_draws, 50));
VAR.CI.MEAN = squeeze(mean(IR_draws, 1));
VAR.IR = VAR.CI.MED;  % set as median values
if (optIR.P_uncertainty ==1) && (optIR.ortho==1)
    VAR.P = squeeze(VAR.IR(1,:,:));  % set as median values
end
VAR.IRdraws = IR_draws;

%Posterior mean of parameters:
VAR.Beta = squeeze(mean(BETA_draws,1)); %posterior mean of ALPHA
VAR.Sigma = squeeze(mean(SIGMA_draws,1)); %posterior mean of SIGMA

%Posterior standard deviations of parameters:
VAR.Beta_std = squeeze(std(BETA_draws,1)); %posterior std of ALPHA
VAR.Sigma_std = squeeze(std(SIGMA_draws,1)); %posterior std of SIGMA
%or you can use 'ALPHA_COV = cov(alpha_draws,1);

% Save draws
VAR.BVARdraws.Beta = BETA_draws;
VAR.BVARdraws.Sigma = SIGMA_draws;
if optIR.ortho==1
    VAR.BVARdraws.P = P_draws;
end

VAR.res = VAR.Y - VAR.X*VAR.Beta;
VAR.SSE = (VAR.res'*VAR.res);
VAR.beta = VAR.Beta(:);

VAR.Comp = [VAR.Beta(1:VAR.nvar*VAR.nlags,:)'; eye(VAR.nvar*(VAR.nlags-1)) zeros(VAR.nvar*(VAR.nlags-1),VAR.nvar)];
VAR.maxEig = max(abs(eig(VAR.Comp)));


VAR.Beta_ols = BETAols;
VAR.beta_ols = betaols;
VAR.SSE_ols = SSEols;
VAR.Sigma_ols = SIGMAols;

optIR.CImethod = 'BVAR';
VAR.optIR = optIR;

end