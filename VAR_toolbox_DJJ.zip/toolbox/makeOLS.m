function OLS = makeOLS(Y,X, trend, varargin)
% Returns one equation OLS result.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Arguments %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% argument 1 : Y   (N*1 vector)
% argument 2 : X   (N*k matrix)
% argument 3 : trend  
%              0: add nothing, 1: constant, 2: linear trend, 3: quadratic
%              If you consider 'HAC' estimater and automatic bandwidth
%              selection, then I recommend you to remove a existing trend
%              from X and set this trend argument.
% < varagin >
% argument 4 : SEtype 
%              'spherical' / 'robust' / 'HAC' / 'cluster'
%              Options 'HAC' / 'cluster' can take additional 5th argument.
%                 'spherical' : Homoskedasticity
%                 'robust'    : Eicker/Huber/White Sandwich estimator
%                 'HAC'       : Newey/West Heteroskedasticity-Autocorrelation-Robust estimator
%                 'cluster'   : Cluster robust estimator
% argument 5 : Additional parameter for SEtype
%              If SEtype=='HAC', 
%                 argument 5 : Lag parameter
%                 Automatic bandwidth selection procedure of Newey & West(1994)
%                 is applied if argument 5 is not given.
%              If SEtype=='cluster', 
%                 argument 5 : cluster ID
% Example
% OLS = makeOLS(Y,X, 1, 'HAC', 7)  % Add contant to X & HAC estimator with the lag 7
%
% VAR_LP_Toolkit Ver. 1.0
% Dong-jae Jung, Bank of Korea
% djjeong@bok.or.kr
% July. 2022
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% 0. Check dimension
if size(Y,1) ~= size(X,1)
    error('Differenct length of X and Y')
end

N = size(Y,1);

% 1. Add trend
nargin_ = nargin;
if ~exist('trend','var')
    trend = 0;   % use original data
    nargin_ = nargin_ +1;
end

Ntrend = 0;
switch trend
    case 1
        X = cat(2, X, ones(N,1));
        Ntrend = 1;
    case 2
        X = cat(2, X, ones(N,1), (1:N)');
        Ntrend = 2;
    case 3
        X = cat(2, X, ones(N,1), (1:N)', ((1:N).*(1:N))');
        Ntrend = 3;
end

k = size(X,2);


% 2. Estimators & Statistics
beta = X\Y;
res = Y - X*beta;
DOF = N-k;
sigma2 = res'*res/DOF;
XXinv = inv(X'*X);

% F statistics
Ydemean = detrend(Y, 'constant');
SStotal = Ydemean'*Ydemean;
SSres   = res'*res;
R2 = 1-SSres/SStotal;
R2adj = 1-SSres/SStotal*(N-1)/(N-k);
F = R2/(1-R2)*(N-k)/(k-1);
pvalueF = fcdf(F,k-1,N-k,'upper');



% 3. Define varagin arguments
switch nargin_
    case 3
        SEtype = 'spherical';
    case 4
        % first input : SEtype
        SEtype = varargin{1};
        if strcmp(SEtype,'HAC')
            lag = 4*(N/100)^(2/9);
            q = 1; % 1: Bartlett,  2: Parzen / QS
            c = 1.1447; % 1.1447 : Bartlett,  2.6614 : Parzen,  1.3221 : QS
            w = [ones(k-Ntrend,1); zeros(Ntrend,1)];
            h = X;
            sig0 =  (h*w)'*(h*w)/(N-k);
            s0 = sig0;
            s1 = zeros(size(sig0));
            for j = 1:lag
                sigj = (h(1:N-j,:)*w)'*(h(1+j:N,:)*w)/(N-k);
                s0 = s0 + 2*sigj;
                s1 = s1 + 2*(j^q)*sigj;
            end
            gamma = c*((s1/s0)^(2/(2*q+1)));
            lag = min(floor(gamma*N^(1/(2*q+1))), N-1);
            OLS.lag = lag;
        end
        OLS.SEtype = SEtype;
    case 5
        SEtype = varargin{1};
        if strcmp(SEtype,'HAC')
            % the case of SEtype= 'HAC'
            % first input : SEtype, second input : bandwidth
            lag = varargin{2};    % bandwidth
            OLS.lag = lag;
        elseif strcmp(SEtype,'cluster')
            % the case of SEtype= 'cluster'
            % first input : SEtype, second input : cluster ID
            ID = varargin{2};    % cluster id
            IDunique = unique(ID);
            OLS.ID = ID;
        end
        OLS.SEtype = SEtype;
end



% 4. Standard Error
switch SEtype
    case 'spherical'
    % Assume Homoskedasticity
        SEbeta = sqrt(diag(XXinv.*sigma2));
    case 'robust'
    % Heteroskedasticity
    % Eicker/Huber/White Sandwich estimator
        mid = zeros(k,k);
        for n = 1:N
            mid = mid + X(n,:)'*X(n,:)*res(n)^2;
        end
        SEbeta = sqrt(diag(XXinv*mid*XXinv));
    case 'HAC'
    % Newey/West Heteroskedasticity-Autocorrelation-Robust estimator
        dfadj = N/(N-k);
        mid = zeros(k,k);
        for n = 1:N
            mid = mid + X(n,:)'*X(n,:).*res(n)^2;
        end
%         J = ceil(N/4);
        J = lag;
        for j = 1:J
            mulj = 1-j/(J+1);
            for n= j+1:N
                mid = mid + mulj*res(n)*res(n-j).*(X(n,:)'*X(n-j,:)+X(n-j,:)'*X(n,:));
            end
        end
        SEbeta = sqrt(diag(dfadj*XXinv*mid*XXinv));
    case 'cluster'
        G = length(IDunique);
        dfadj = G/(G-1)*(N-1)/(N-k);
        mid = zeros(k,k);
        for g = 1:G
            gidx = (ID==g);
            Yg = Y(gidx,:);
            Xg = X(gidx,:);
            resg = res(gidx,:);
            mid = mid + Xg'*resg*resg'*Xg;
        end
        SEbeta = sqrt(diag(dfadj*XXinv*mid*XXinv));
end

% 4-1: SEbeta dependent statistics
tstat = beta./SEbeta;
pvalue = 1- (tcdf(abs(tstat), DOF*ones(k,1)) - tcdf(-abs(tstat), DOF*ones(k,1)));


% 5. Store
OLS.Y = Y;  OLS.X = X;
OLS.Nobs = N;
OLS.Ncoef = k;
OLS.Ntrend = Ntrend;

OLS.beta = beta;
OLS.res = res;
OLS.DOF = DOF;
OLS.Sigma2 = sigma2;
OLS.SEbeta = SEbeta;
OLS.tstat = tstat;
OLS.pvalue = pvalue;
OLS.R2 = R2;
OLS.R2adj = R2adj;
OLS.F =F;
OLS.pvalueF =pvalueF;

end
