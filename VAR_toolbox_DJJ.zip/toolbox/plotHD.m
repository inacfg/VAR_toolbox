%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% VAR_LP_Toolkit Ver. 1.0
% Dong-jae Jung, Bank of Korea
% djjeong@bok.or.kr
% July. 2022
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function plotHD(VAR, plotVar, shockVar, optPlot)

if ~isfield(optPlot, 'newfig')
    optPlot.newfig = 1;
end
if ~isfield(optPlot, 'Color')
    optPlot.Color = 'k';
end
if ~isfield(optPlot, 'LineStyle')
    optPlot.LineStyle = '-';
end
if ~isfield(optPlot, 'LineWidth')
    optPlot.LineWidth = 2;
end
if ~isfield(optPlot, 'Stochastic')
    optPlot.Stochastic = 1;
end

if isempty(shockVar)
    shockVar = VAR.varnamesX;
end
if ischar(shockVar)
    shockVar = {shockVar};
end

if optPlot.newfig
    figure
end

screensize = get(0, 'Screensize');
sc_hor = screensize(3);
sc_ver = screensize(4);

fig=gcf;
% fig.Position(3:4)=[400*3,300*4];
fig.Position(3:4)=[sc_hor*2/3,sc_ver*2/3];
fig.Position(1) = (sc_hor-fig.Position(3))/2;
fig.Position(2) = (sc_ver-fig.Position(4))/2;


% plotVar = 'CPI';
plotidx = find(strcmp(VAR.varnamesX, plotVar));
shockidx = find(strcmp(VAR.varnamesX, shockVar));

HD = VAR.HD;
HDdetail = VAR.HDdetail;
Deffect = HDdetail.Deffect;
Y = VAR.Y(:,plotidx);
HDvar = squeeze(HD(:,plotidx,shockidx));
Deffectvar = Deffect(:,plotidx);


% 1. All (include deterministic part : trend, exo vars, initial Y condition)
if optPlot.Stochastic==0
HDforplot = cat(2, HDvar, Deffectvar);

bar(VAR.Date, HDforplot(:,:)','stacked', 'FaceAlpha',0.5); hold on;
lgd = shockVar;
lgd{end+1} = 'Deterministic';
plot(VAR.Date, Y, 'LineStyle',optPlot.LineStyle,'Color',optPlot.Color, 'LineWidth',optPlot.LineWidth)
lgd{end+1} = 'Y';
legend(lgd)
title(['Historical Decomposition of ', VAR.varnamesX{plotidx}])
end


% 2. Only stochastic parts
if optPlot.Stochastic
Ysto = Y - Deffectvar;

bar(VAR.Date, HDvar','stacked', 'FaceAlpha',0.5); hold on;
lgd = shockVar;
plot(VAR.Date, Ysto, 'LineStyle',optPlot.LineStyle,'Color',optPlot.Color, 'LineWidth',optPlot.LineWidth)
lgd{end+1} = 'Y';
legend(lgd)
title(['Historical Decomposition of ', VAR.varnamesX{plotidx}, ' (only for stochastic parts)'])
end
