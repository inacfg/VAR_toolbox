function VAR = forecastVAR(VAR, foreT, foreStart, Exo, plotFore)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% foreT : horizon for the forecasting
% foreStart : index at which the forecasting begins
% Exo : exogenous variable input for the forecast

% VAR_LP_Toolkit Ver. 1.0
% Dong-jae Jung, Bank of Korea
% djjeong@bok.or.kr
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
nvar = VAR.nvar;
T = VAR.T;
if foreStart>T+1
    error("Starting point of forecasting should be equal or less than T+1 (foreStart<=T+1)")
end
Nendo = VAR.Nendo;
nadd = VAR.Nexo+VAR.Ntrend;
BigComp = [VAR.Beta(1:VAR.nvar*VAR.nlags+nadd,:)'; eye(VAR.nvar*(VAR.nlags-1)) zeros(VAR.nvar*(VAR.nlags-1),VAR.nvar+nadd) ; zeros(nadd, VAR.Nx)];

Tfore = max(T, foreStart-1+foreT);
Yfore = zeros(Tfore, nvar);
Xfore = zeros(Tfore, VAR.Nendo+VAR.Nexo);

Yfore(1:foreStart-1,:) = VAR.Y(1:foreStart-1,:);
Xfore(1:foreStart-1,:) = VAR.X(1:foreStart-1, 1:end-VAR.Ntrend);

% for exo vars, use given Exo, or use mean value for the forecasting
if ~exist('Exo', 'var') || isempty(Exo)
    Xfore(foreStart:Tfore, VAR.Nendo+1:VAR.Nendo+VAR.Nexo) = mean(Xfore(1:foreStart-1, VAR.Nendo+1:VAR.Nendo+VAR.Nexo), 1);
elseif size(Exo,1)~=Tfore
    error(['Length of the exogeneous input should equal to total # of periods : ' num2str(Tfore) ' (foreStart-1+foreT)'])
else
    Xfore(foreStart:Tfore, VAR.Nendo+1:VAR.Nendo+VAR.Nexo) = Exo;        
end


switch VAR.trend
    case 1
        Xfore = cat(2, Xfore, ones(Tfore,1));
    case 2
        Xfore = cat(2, Xfore, ones(Tfore,1), (1:Tfore)');
    case 3
        Xfore = cat(2, Xfore, ones(Tfore,1), (1:Tfore)', ((1:Tfore).*(1:Tfore))');
end

Ytt = [Yfore(foreStart-1,1:nvar) Xfore(foreStart-1, 1:Nendo-nvar) zeros(1,nadd)];
for t = 1:foreT
    tt = foreStart-1+t;
    Xfore(tt, 1:Nendo) = Ytt(1:Nendo);
    Ytt = BigComp*Xfore(tt, :)'; 
    Yfore(tt, :) = Ytt(1:nvar)';
end

% Store
VAR.Forecast.foreT = foreT;
VAR.Forecast.foreStart = foreStart;
VAR.Forecast.Forecast = Yfore;
VAR.Forecast.XforForecast = Xfore;

% Plot
if ~exist('plotFore', 'var')
    plotFore=1;
end

if plotFore
    nr = floor((nvar-1)/5)+1;
    nc = min(nvar,5);
    screensize = get(0, 'Screensize');
    sc_hor = screensize(3);
    sc_ver = screensize(4);

    % Plot known Y also
    plotKnownY = 0;
    if foreStart<T
        plotKnownY = 1;
        knownY = VAR.Y(foreStart-1:min(foreStart-1+foreT,T),:);
        xxKnown = 0:size(knownY,1)-1;
    end

    figure
    fig=gcf;
    fig.Position(3:4)=[400*nc,300*nr];
    fig.Position(1) = (sc_hor-fig.Position(3))/2;
    fig.Position(2) = (sc_ver-fig.Position(4))/2;

    xx = 0:foreT;
    for i = 1:nvar
        iidx = floor((i-1)/5)+1; jidx = i-(iidx-1)*5;
        subplot(nr, nc, jidx+(iidx-1)*nc)    
        plot(xx, Yfore(foreStart-1:Tfore, i))
        if plotKnownY
            hold on
            plot(xxKnown, knownY(:, i), 'k:')
            legend('Forecasted','Observed')
        end
        title(['Forecasting of ' VAR.varnames{i}]); 
    end
end

end