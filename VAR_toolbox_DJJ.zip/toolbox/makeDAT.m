function [DAT, dateval, VAR] = makeDAT(DATraw, dateval, varnamesX, tcodeX, varnamesExo, tcodeExo)

colnames = DATraw.Properties.VariableNames;
dtype = varfun(@class,DATraw,'OutputFormat','cell');

% 1. Construct Subset
if isempty(varnamesExo)
    varnamesExo = [];
end
col_c = strcmp(dtype,'cell');
col_c_names = colnames(col_c);
for i = 1:length(col_c_names)
    DATraw.(char(col_c_names(i))) = str2double(DATraw.(char(col_c_names(i))));
end
col_d = strcmp(dtype,'datetime');
col_exo = strcmp(colnames, varnamesExo);
if isempty(varnamesX)
    if isempty(dateval)
        if sum(strcmp(colnames,'t'))
            dateval = DATraw.t;
        end
    end
    varnamesX = colnames(~col_d&~col_exo);
end
% varnames = {'GDP','CPI','L','Call'};
% varnamesExo = {'CRISIS'};
varnames = [varnamesX varnamesExo];
DAT = DATraw(:,varnames);

% 2. Transfoamtion of variables
if isempty(tcodeX)
    tcodeX = ones(1,length(varnamesX));
end
if isempty(tcodeExo)
    tcodeExo = ones(1,length(varnamesExo));
end
tcode = [tcodeX tcodeExo];

for j = 1:length(tcode)
    DAT{:,j} = dataTransform(DAT{:,j}, tcode(j));
%     if tcode(j)==2
%         DAT{:,j} = DAT{:,j}*100;
%     end
end

% 3. Make Full Sample Data
chknull = isnan(sum(DAT{:,1:end},2));
DAT = DAT(~chknull,:);

if isempty(dateval)
    dateval = 1:size(DAT, 1);
else
    dateval = dateval(~chknull);
end

VAR.varnames = varnames;
VAR.varnamesX = varnamesX;
VAR.varnamesExo = varnamesExo;
VAR.tcode = tcode;
VAR.tcodeX = tcodeX;
VAR.tcodeExo = tcodeExo;

VAR.Date = dateval;
end

