function VAR = hd(VAR, optIR)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Historical decomposition
%
% VAR_LP_Toolkit Ver. 1.0
% Dong-jae Jung, Bank of Korea
% djjeong@bok.or.kr
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

nvar = VAR.nvar;
nlags = VAR.nlags;
T = VAR.T;
res = VAR.res;

Ortho = optIR.ortho;
if Ortho == 1
    if optIR.unitshock
        PP = VAR.Pnorm;
    else
        PP = VAR.P;
    end
elseif Ortho ==0
    if optIR.unitshock
        PP = eye(nvar,nvar);
    else
        PP = diag(sqrt(diag(VAR.Sigma)));
    end
else
    error('optCI.ortho must be 1 or 0')
end

orth_shock = PP\res';

optIRhd = optIR;
optIRhd.IRhor = T;
optIRhd.CImethod = 'None';
% optIRhd.unitshock = 0;
% VARhd = ImpulseResponse(VAR, optIRhd);
VARhd = IRVAR(VAR, optIRhd);
IRhd = VARhd.IR;

HD = zeros(size(IRhd));
for v = 1:nvar
    IRhdv = squeeze(IRhd(:,v,:))';
    for t = 1:T
        HD(t,v,:) = sum(fliplr(IRhdv(:,1:t)) .* orth_shock(:,1:t), 2);
    end
end


SHOCKeffect = sum(HD,3);  % Contribution of shocks
% tmp = repmat(HDshocksum,1,1,nvar);
% HDratio = HD./tmp;

nadd = VAR.Nexo+VAR.Ntrend;
BigComp = [VAR.Beta(1:VAR.nvar*VAR.nlags+nadd,:)'; eye(VAR.nvar*(VAR.nlags-1)) zeros(VAR.nvar*(VAR.nlags-1),VAR.nvar+nadd) ; zeros(nadd, VAR.Nx)];
Y0effect = zeros(T,nvar);  % Contribution of initial Y
PSI = eye(size(BigComp));
EE = [eye(nvar) ; zeros(nvar*(nlags-1)+nadd, nvar)];
EEendo = [eye(nvar*nlags) ; zeros(nadd,nvar*nlags) ];
EEexo = [zeros(nvar*nlags,VAR.Nexo) ; eye(VAR.Nexo); zeros(VAR.Ntrend,VAR.Nexo)];
EEtrend = [zeros(nvar*nlags+VAR.Nexo,VAR.Ntrend) ; eye(VAR.Ntrend)];
EXOeffect = zeros(nvar,T);  % Contribution of exo vars
TRENDeffect = zeros(nvar,T);  % Contribution of trends
for t =1:T
    PSI = BigComp*PSI;
    Y0effect(t,:) = EE'*PSI*EEendo*(VAR.X(1, :)*EEendo)';
    exoeffect_t = EE'*PSI*EEexo*(VAR.X*EEexo)';
    EXOeffect(:,t:end) = EXOeffect(:,t:end) + exoeffect_t(:,1:end-t+1);
    trendeffect_t = EE'*PSI*EEtrend*(VAR.X*EEtrend)';
    TRENDeffect(:,t:end) = TRENDeffect(:,t:end) + trendeffect_t(:,1:end-t+1);
end

Deffect = Y0effect+EXOeffect'+TRENDeffect';
TOTALeffect = Deffect + SHOCKeffect;

%%
VAR.HD = HD;
VAR.HDdetail.SHOCKeffect = SHOCKeffect;
VAR.HDdetail.Y0effect = Y0effect;
VAR.HDdetail.EXOeffect = EXOeffect;
VAR.HDdetail.TRENDeffect = TRENDeffect;
VAR.HDdetail.Deffect = Deffect;
VAR.HDdetail.TOTALeffect = TOTALeffect;

end
