function VAR = simulVAR(VAR, SHOCKs, orthoSim, simT)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% orthoSim : 1 if given SHOCKs are orthogonal shocks,  0 otherwise
% simT : # of simulation periods after SHOCKs
%        SHOCKS in simT are assumed to be zero

% foreT : horizon for the forecasting
% foreStart : index at which the forecasting begins
% Exo : exogenous variable input for the forecast

% VAR_LP_Toolkit Ver. 1.0
% Dong-jae Jung, Bank of Korea
% djjeong@bok.or.kr
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
nvar = VAR.nvar;
T = VAR.T;
Tshocks = size(SHOCKs,1);
Tsim = Tshocks + simT;

SHOCKs_f = zeros(Tsim, size(SHOCKs,2));
SHOCKs_f(1:Tshocks, :) = SHOCKs;
% orth_shock = PP\res';

optIRhd = VAR.optIR;
optIRhd.ortho = orthoSim;
optIRhd.IRhor = Tsim;
optIRhd.CImethod = 'None';
% optIRhd.unitshock = 0;
% VARhd = ImpulseResponse(VAR, optIRhd);
VARhd = IRVAR(VAR, optIRhd);
IRhd = VARhd.IR;

SIM = zeros(Tsim, nvar);
for v = 1:nvar
    IRhdv = squeeze(IRhd(:,v,:))';
    for t = 1:Tsim
        SIM(t,v) = sum(sum(fliplr(IRhdv(:,1:t)) .* SHOCKs_f(1:t,:)', 2), 1);
    end
end

% Use forecasting values for the baseline path with no SHOCKs
if Tsim > T
    foreStart = T+1;
    foreT = Tsim - T;
    VARfore = forecastVAR(VAR, foreT, foreStart, [],0);
    Baseline = VARfore.Forecast.Forecast;
else
    Baseline = VAR.Y(1:Tsim,:);
end

% Store
VAR.Simul.SHOCKs = SHOCKs;
VAR.Simul.orthoSim = orthoSim;
VAR.Simul.simT = simT;

VAR.Simul.Baseline = Baseline;
Simulated = Baseline - SIM;
VAR.Simul.Simulated = Simulated;
VAR.Simul.NetEffect = SIM;

% Plot
nr = floor((nvar-1)/5)+1;
nc = min(nvar,5);
screensize = get(0, 'Screensize');
sc_hor = screensize(3);
sc_ver = screensize(4);

% % Plot known Y also
% plotKnownY = 0;
% if foreStart<T
%     plotKnownY = 1;
%     knownY = VAR.Y(foreStart-1:min(foreStart-1+foreT,T),:);
%     xxKnown = 0:size(knownY,1)-1;
% end

figure
fig=gcf;
fig.Position(3:4)=[400*nc,300*nr];
fig.Position(1) = (sc_hor-fig.Position(3))/2;
fig.Position(2) = (sc_ver-fig.Position(4))/2;

xx = [-(Tshocks-1):0 1:simT];
for i = 1:nvar
    iidx = floor((i-1)/5)+1; jidx = i-(iidx-1)*5;
    subplot(nr, nc, jidx+(iidx-1)*nc)    
    plot(xx, Baseline(:, i), 'k'); hold on
    plot(xx, Simulated(:,i))
    legend('Baseline','Simulation')
    title(['Simulation of ' VAR.varnames{i}]); 
end

% Plot only for the simulation period
figure
fig=gcf;
fig.Position(3:4)=[400*nc,300*nr];
fig.Position(1) = (sc_hor-fig.Position(3))/2;
fig.Position(2) = (sc_ver-fig.Position(4))/2;

xx = [0:simT];
for i = 1:nvar
    iidx = floor((i-1)/5)+1; jidx = i-(iidx-1)*5;
    subplot(nr, nc, jidx+(iidx-1)*nc)    
    plot(xx, Baseline(Tshocks:end, i), 'k'); hold on
    plot(xx, Simulated(Tshocks:end,i))
    legend('Baseline','Simulation')
    title(['Simulation of ' VAR.varnames{i}]); 
end

end