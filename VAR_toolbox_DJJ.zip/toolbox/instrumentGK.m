function VAR = instrumentGK(VAR)
% Structural Identification using external instruments by Gertler & Karadi(2015)
% Instrumented variable (i.e. monetary policy indicator) should be ordered at first.
% Instruments need to be given in matrix VAR.Z.
%
% Dong-jae Jung, Bank of Korea
% djjeong@bok.or.kr

Z = VAR.Z;
if size(Z,1) ~= VAR.T
    error('Observations in Z should equal to VAR.T')
end

Sigma = VAR.Sigma;
nvar = VAR.nvar;
Sig11 = Sigma(1,1);
Sig21 = Sigma(2:nvar,1);
Sig22 = Sigma(2:nvar,2:nvar);

up = VAR.res(:,1);
Uq = VAR.res(:,2:end);

Z_ = [Z, ones(length(Z),1)]; 
% stage1res = up - Z_*(Z_\up);
% stage1 = makeOLS(up, Z, 1);
% uphat = eq - stage1res;
uphat = Z_*(Z_\up);

uphat_ = [uphat, ones(length(uphat),1)]; 
stage2beta = uphat_\Uq;
% stage2 = makeOLS(Uq, uphat, 1);
Sqsp = stage2beta(1, :)'; % S21/s11

Q = Sqsp*Sig11*Sqsp' - (Sig21*Sqsp' +Sqsp*Sig21') +Sig22;
S12S12p = (Sig21-Sqsp*Sig11)'*(Q\(Sig21-Sqsp*Sig11));
sp = sqrt(Sig11 - S12S12p);
Sq = Sqsp*sp;
P = zeros(nvar);
P(1,1) = sp;
P(2:end, 1) = Sq;

% VAR.A = eye(nvar);
% VAR.B = B;
VAR.P = P;
VAR.Pnorm = P;
end