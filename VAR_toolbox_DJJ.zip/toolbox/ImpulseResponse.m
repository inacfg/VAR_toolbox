function Model = ImpulseResponse(Model, optIR)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Model Choice : VAR, LP
% Set Model.IRmethod = 'VAR' or 'LP'
%
% This function returns Impulse Responses, and
% return Confidence Intervals if optIR.CImethod~=None
%
% (1) Confidence Interval Method
% Possible optIR.CImethod : 
%       1. 'None'                       : Do not calculate CI
%       2. 'asymptotic'
%       3. 'bootstrap'
%       4. 'bootstrap-after-bootstrap'
%
% If optIR.CImethod='bootstrap'or'bootstrap-after-bootstrap', optIR.nboot is required (default 1000)
%
% (2) Impulse Response Type
% optIR.ortho = 1, if want orthogonalized impulse responses
%             = 0, if not
% optIR.unitshock = 1, if want unitary shock IR
%                 = 0, if want one SD shock IR
%
% (3) Structural Shock
% Structural restrictions are given with matrices P, A, B, LR
% If P matrix given, there is no further calculation and just use P for the IR. (i.e., P = inv(A)*B )
% If NONE of P, A, B matrices are given, assuming the recursive restriction.
% If only one of A, B matrix is given, the other B or A matrix is assumed to be an identity matrix.
% If BOTH A and B matrices are given, this infers a AB-model.
% If you want long-run restrictions, use LR matrix.
% If you want to mix LR & SR restrictions, use LR & B matrices. In this case,
%    note that only B-model is plausible for the short-run restrictions.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Method for CI
if ~exist('optIR', 'var')
    optIR.CImethod = 'None';
end
CImethod = optIR.CImethod;

if (~strcmp(CImethod,'None')) && (~strcmp(CImethod,'asymptotic')) 
    if ~isfield(optIR, 'nboot')
        optIR.nboot = 1000;  % Default : 1,000 times of bootstrap
    end
end

%% IR method
if ~isfield(Model, 'IRmethod')
    Model.IRmethod = 'VAR';          % Default : VAR
end

switch Model.IRmethod
    case 'VAR'        
        if ~isfield(optIR, 'ortho')
            optIR.ortho = 1;         % VAR Default : orthogonalized IR
        end
        if ~isfield(optIR, 'unitshock')
            optIR.unitshock = 0;     % VAR Default : One SD shock
        end       
        if optIR.ortho == 1
            Model = structuralIR(Model, optIR);
        end
        Model = IRVAR(Model, optIR);
    case 'LP'    
        if ~isfield(optIR, 'ortho')
            optIR.ortho = 0;         % LP Default : Non-orthogonalized IR
        end
        if ~isfield(optIR, 'unitshock')
            optIR.unitshock = 1;     % LP Default : Unitary shock
        end  
        if optIR.ortho == 1
            Model = structuralIR(Model, optIR);
        end      
        Model = IRLP(Model, optIR);
    case 'BVAR'        
        if ~isfield(optIR, 'ortho')
            optIR.ortho = 1;         % BVAR Default : orthogonalized IR
        end
        if ~isfield(optIR, 'unitshock')
            optIR.unitshock = 0;     % BVAR Default : One SD shock
        end       
        if optIR.ortho == 1
            Model = structuralIR(Model, optIR);
        end
        Model = IRBVAR(Model, optIR);
end

end