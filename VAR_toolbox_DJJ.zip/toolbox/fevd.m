function VAR = fevd(VAR)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Forecasting error variance decomposition
%
% VAR_LP_Toolkit Ver. 1.0
% Dong-jae Jung, Bank of Korea
% djjeong@bok.or.kr
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if VAR.optIR.ortho~=1
    error('Orthogonal shocks(optIR.ortho==1) are required.')
end
if ~isfield(VAR, 'FEVDhor')
    VAR.FEVDhor = 12;
end
FEVDhor = VAR.FEVDhor;

nvar = VAR.nvar;
nlags = VAR.nlags;

switch VAR.IRmethod
    case {'BVAR', 'BVAR_SIGN'}        
        if ~isfield(VAR, 'FEVD_CIlevel')
            VAR.FEVD_CIlevel = VAR.optIR.CIlevel;
        end        
        cl = round((100-VAR.FEVD_CIlevel)/2);        
        ndraws = size(VAR.BVARdraws.Beta,1);
        
        FEVDs = zeros(ndraws, nvar, nvar, FEVDhor);
        FEVs = zeros(ndraws, nvar, nvar, FEVDhor);        
        VARi = struct();
        VARi.nvar = nvar;
        VARi.nlags = nlags;
        VARi.FEVDhor = FEVDhor;
        for i = 1:ndraws
            BETAi = squeeze(VAR.BVARdraws.Beta(i,:,:));
            VARi.Sigma = squeeze(VAR.BVARdraws.Sigma(i,:,:));
            VARi.P = squeeze(VAR.BVARdraws.P(i,:,:));
            VARi.Comp = [BETAi(1:nvar*nlags,:)'; eye(nvar*(nlags-1)) zeros(nvar*(nlags-1),nvar)];
            VARi = fevd_for_i(VARi);
            FEVDs(i,:,:,:) = VARi.FEVD;
            FEVs(i,:,:,:) = VARi.FEV;
        end
        
        VAR.FEVDdraws.FEVDs = FEVDs;
        VAR.FEVDdraws.FEVs = FEVs;
        VAR.FEVDdraws.CI.INF = squeeze(prctile(FEVDs, cl));
        VAR.FEVDdraws.CI.SUP = squeeze(prctile(FEVDs, 100-cl));
        VAR.FEVDdraws.CI.MED = squeeze(prctile(FEVDs, 50));
        VAR.FEVDdraws.CI.MEAN = squeeze(mean(FEVDs, 1));
    otherwise
        VAR = fevd_for_i(VAR);
end
end
        
        
% function for single run of FEVD
function VAR = fevd_for_i(VAR)
P = VAR.P;
Sigma = VAR.Sigma;
Comp = VAR.Comp;
nvar = VAR.nvar;
nlags = VAR.nlags;
FEVDhor = VAR.FEVDhor;
J = [eye(nvar) zeros(nvar, nvar*(nlags-1))];

FEVD = zeros(nvar, nvar, FEVDhor);  % variance decomposition of i variable by shock j
FEV = zeros(nvar, nvar, FEVDhor);
MSEmat = zeros(nvar, FEVDhor);
Compt = Comp^0;
MSEt = zeros(size(Sigma));
FEVt = zeros(size(Sigma));
for t =1:FEVDhor
    PSI = J*Compt*J';
    MSEt = MSEt + PSI*Sigma*PSI';
    MSEmat(:,t) = diag(MSEt);
    FEVt = FEVt+(PSI*P).^2;
    FEV(:,:,t) = FEVt;
    Compt = Comp*Compt;
    
%     MSEmat2 = squeeze(sum(FEV,2));
    FEVD(:,:,t) = FEV(:,:,t)./repmat(MSEmat(:,t), 1, nvar);
end
VAR.FEVD = FEVD;
VAR.FEV = FEV;

end