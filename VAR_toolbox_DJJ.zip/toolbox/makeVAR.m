function VAR = makeVAR(DAT, VAR)

if ~isfield(VAR, 'trend')
    VAR.trend = 1;   % include constant
end
if ~isfield(VAR, 'IRhor')
    VAR.IRhor = 11;   % Horizon for IR
end


% Exo =  DAT{:,{'CRISIS'}};
Y =  DAT{:,VAR.varnamesX};
VAR.nvar       = size(Y,2);                                           
nlags = VAR.nlags;                                                    % number of lags

X = zeros(size(Y,1), nlags*size(Y,2));
for i = 1:nlags
    X(:,VAR.nvar*(i-1)+1:VAR.nvar*i) = cat(1, zeros(i,VAR.nvar), Y(1:end-i,:));
end

X = X(nlags+1:end,:);  Y = Y(nlags+1:end,:); dateval = VAR.Date(nlags+1:end);
VAR.ENDO = X;                                   
VAR.T = size(Y,1);

if isfield(VAR, 'varnamesExo')
    Exo = DAT{nlags+1:end,VAR.varnamesExo};
    VAR.Exo = Exo;
    VAR.Nexo = size(Exo,2);
    X = cat(2, X, Exo);
end

switch VAR.trend
    case 1
        X = cat(2, X, ones(VAR.T,1));
    case 2
        X = cat(2, X, ones(VAR.T,1), (1:VAR.T)');
    case 3
        X = cat(2, X, ones(VAR.T,1), (1:VAR.T)', ((1:VAR.T).*(1:VAR.T))');
end
VAR.Ntrend = VAR.trend;

VAR.X = X;
VAR.Y = Y;    
VAR.Date = dateval;
    
VAR.Nendo = size(VAR.ENDO,2);
VAR.Nx = size(X,2);
                                      
VAR.h         = 0:1:(VAR.IRhor-1);   
end
