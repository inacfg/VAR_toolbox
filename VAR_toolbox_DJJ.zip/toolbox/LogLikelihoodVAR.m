%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% VAR_LP_Toolkit Ver. 1.0
% Dong-jae Jung, Bank of Korea
% djjeong@bok.or.kr
% July. 2022
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [LL] =LogLikelihoodVAR(para, VAR)
% log-likelihood for VAR model with multivariate normal dist. errors
% k = sqrt(length(P));
% P = reshape(P, k,k);

A = VAR.A;
locA =  VAR.locA;
NparaA = VAR.NparaA;
B = VAR.B;
locB = VAR.locB;
NparaB = VAR.NparaB;

paraA = para(1:NparaA);
paraB = para(NparaA+1:NparaA+NparaB);
% para = rand(NparaB,1);
% para2 = chol(VAR.Sigma, 'lower');
% para2 = para2(locB);
A(locA) = paraA;
B(locB) = paraB;

Sigma = VAR.Sigma;
% k = VAR.Nx;
T = VAR.T;

if isfield(VAR, 'LR')   % for LR restriction
    LRM = VAR.LRM;
    row = VAR.LRloc(:,1);
    col = VAR.LRloc(:,2);
    freeB = VAR.LRloc(:,3);
    uniquecol = unique(col);
    Nequ = length(uniquecol);
    for ci = 1:Nequ
        coli = uniquecol(ci);
        iidx = (col==coli);
        rowi = row(iidx);
        freeBi = freeB(iidx);
        nonfreeBi = setdiff(1:size(B,1), freeBi);
        B(freeBi,coli) = LRM(rowi,freeBi)\(VAR.LR(rowi, coli) - LRM(rowi,nonfreeBi)*B(nonfreeBi,coli));
    end
end

if rank(B)<size(B,1)
    disp('     Warning : Matrix B is singular in some parameter space')
end
P = B\A;
LL = T/2*log(det(A)^2) -T/2*log(det(B)^2) -T/2*trace((P'*P)*Sigma);  % constant ignored -(T*k/2)*log(2*pi) 

end

