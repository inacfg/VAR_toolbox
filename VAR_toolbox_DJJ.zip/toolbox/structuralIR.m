function Model = structuralIR(Model, optIR)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Structural restrictions are given with matrices P, A, B, LR
% (1) P matrix given, there is no further calculation and just use P for the IR. (i.e., P = inv(A)*B )
% (2) if NONE of P, A, B matrices are given, assuming the recursive restriction.
% (3) If only one of A, B matrix is given, the other B or A matrix is assumed to be an identity matrix.
% (4) If BOTH A and B matrices are given, this infers a AB-model.
% (5) If you want long-run restrictions, use LR matrix.
% (6) If you want to mix LR & SR restrictions, use LR & B matrices. In this case,
%     note that only B-model is plausible for the short-run restrictions.
%
% VAR_LP_Toolkit Ver. 1.0
% Dong-jae Jung, Bank of Korea
% djjeong@bok.or.kr
% July. 2022
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Structural Shock
if ~isfield(Model, 'Sigma')    
    Model = VAR_ols(Model);
end

if optIR.ortho == 1
    % if P given, use P as IR
    if isfield(Model, 'P')
    elseif ~isfield(Model, 'A') && ~isfield(Model, 'B') % if all of P,A,B are not given, assume recursive ordering
        [P, flag] = chol(Model.Sigma, 'lower');
        Model.P = P;
    else
        if isfield(Model, 'A') && ~isfield(Model, 'B')
            Model.B = eye(Model.nvar);
        elseif ~isfield(Model, 'A') && isfield(Model, 'B')
            Model.A = eye(Model.nvar);
        end 
        locA = isnan(Model.A);  
        locB = isnan(Model.B);
%         if max(abs(Model.A-eye(Model.nvar)) +abs(locB-tril(ones(Model.nvar,Model.nvar))), [],'all' ) +max(abs(Model.B(~locB)-Model.B(~locB)*0), [],'all' ) < 0.0001   % If Given AB system is the B system for cholesky ordering
        if max(reshape(abs(Model.A-eye(Model.nvar)),1,[])) +max(reshape(abs(locB-tril(ones(Model.nvar,Model.nvar))), 1, [])) +max(reshape(abs(Model.B(~locB)-Model.B(~locB)*0), 1,[])) < 0.0001   % If Given AB system is the B system for cholesky ordering
            [P, flag] = chol(Model.Sigma, 'lower');
            Model.P = P;
        else
            if isfield(Model, 'LR') % for LR restriction
                Beta = Model.Beta';
                LRM = eye(Model.nvar);
                for ll =1:Model.nlags
                    LRM = LRM - Beta(:,(ll-1)*Model.nvar+1:ll*Model.nvar);
                end
                LRM = eye(Model.nvar)/LRM;   % LR multiplier
                Model.LRM = LRM;
                
%                 locBmod = locB;
                locLR = isnan(Model.LR);
                [row,col] = ind2sub(size(locLR), find(~locLR));
                freeB = zeros(size(row));
                for i = 1:length(row)
                    freeBi = find(locB(:,col(i)));
                    freeB(i) = freeBi(1);     % replace B(freeBi, coli) according to the LR constraint
                    locB(freeB(i),col(i)) = 0;
                end
                Model.LRloc = [row,col,freeB];
            end

            Model.locA = locA; Model.locB = locB;
%             NparaA = sum(locA,'all'); NparaB = sum(locB,'all');  
            NparaA = sum(reshape(locA,1,[])); NparaB = sum(reshape(locB,1,[]));  % fore pre vers. of Matlab 2018
            Model.NparaA = NparaA; Model.NparaB = NparaB;            
            
            if ~isfield(optIR, 'para_ini')
                optIR.para_ini = ones(NparaA+NparaB,1);
            end
            warning('off','MATLAB:singularMatrix')
%             LogLikelihoodVAR(para, Model);
            fnLL = @(x) -1*LogLikelihoodVAR(x, Model);
            options = optimoptions(@fminunc,'Display','notify-detailed','Algorithm','quasi-newton');
            [para,fval,exitflag,output] = fminunc(fnLL,optIR.para_ini,options);
    %         options = optimset('Display','iter');
    %         [x2,fval,exitflag,output] = fminsearch(fnLL,para,options); 
            optIR.para = para;
            warning('on','MATLAB:singularMatrix')
            paraA = para(1:NparaA);
            paraB = para(NparaA+1:NparaA+NparaB);
            Ahat = Model.A; Ahat(locA)=paraA;  
            Bhat = Model.B; Bhat(locB)=paraB;
            if isfield(Model, 'LR')   % for LR restriction
                uniquecol = unique(col);
                Nequ = length(uniquecol);                
                for ci = 1:Nequ
                    coli = uniquecol(ci); iidx = (col==coli); rowi = row(iidx); freeBi = freeB(iidx); nonfreeBi = setdiff(1:size(locB,1), freeBi);
                    Bhat(freeBi,coli) = LRM(rowi,freeBi)\(Model.LR(rowi, coli) - LRM(rowi,nonfreeBi)*Bhat(nonfreeBi,coli));
                end
%                 for i = 1:length(row)
%                     rowi = row(i); coli = col(i); freeBi = freeB(i);
%                     Bhat(freeBi,coli) = (LRM(rowi,setdiff(1:end,freeBi))*Bhat(setdiff(1:end,freeBi),coli) - Model.LR(rowi, coli))/(-LRM(rowi,freeBi));
%                 end
            end
            
            Ahat = Ahat*diag(sign(diag(Ahat))); 
            Bhat = Bhat*diag(sign(diag(Bhat)));   
            Model.Ahat = Ahat; Model.Bhat = Bhat;
            Model.P = Ahat\Bhat;
        end
    end
    
    if ~isfield(Model, 'Pnorm')
        Pnorm = Model.P/diag(diag(Model.P));
        Model.Pnorm = Pnorm;  % Normalization
    end
%     if optIR.unitshock
%         PP = Model.P;
%     else
%         PP = Model.Pnorm;
%     end
% elseif optIR.ortho ==0
%     if optIR.unitshock
%         PP = eye(nvar,nvar);
%     else
%         PP = diag(sqrt(diag(Model.Sigma)));
%     end
% else
%     error('optIR.ortho must be 1 or 0')
end
end