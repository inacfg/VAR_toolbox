function VAR_plot(VAR, shockvar, resvar, optplot)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Impulse Response Plotting Option
% optplot.newfig
% optplot.Color
% optplot.LineStyle
%
% VAR_LP_Toolkit Ver. 1.0
% Dong-jae Jung, Bank of Korea
% djjeong@bok.or.kr
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if ~isfield(optplot, 'newfig')
    optplot.newfig = 1;
end
if ~isfield(optplot, 'Color')
    optplot.Color = 'k';
end
if ~isfield(optplot, 'LineStyle')
    optplot.LineStyle = '-';
end

if optplot.newfig
    figure
end
% nvar = VAR.nvar;

% shockvar = {'Call'};
% resvar = {'GDP','CPI','L','Call'};
shockidx = zeros(1,length(shockvar));
for i = 1:length(shockvar)
    shockidx(i) = find(strcmp(VAR.varnamesX, shockvar(i)));
end
residx = zeros(1,length(resvar));
for i = 1:length(resvar)
    residx(i) = find(strcmp(VAR.varnamesX, resvar(i)));
end

nshock = length(shockidx);
nres = length(residx);

screensize = get(0, 'Screensize');
sc_hor = screensize(3);
sc_ver = screensize(4);

fig=gcf;
% fig.Position(3:4)=[400*3,300*4];
fig.Position(3:4)=[400*nres,300*nshock];
fig.Position(1) = (sc_hor-fig.Position(3))/2;
fig.Position(2) = (sc_ver-fig.Position(4))/2;

xhor = 0:1:VAR.IRhor-1;
% row: shock, column: response
for i = 1:nshock
    for j = 1:nres
        iidx = shockidx(i); jidx = residx(j);
        subplot(nshock, nres, j+(i-1)*nres)
        plot(xhor, VAR.IR(:,jidx,iidx),'LineStyle',optplot.LineStyle,'Color',optplot.Color)
        hold on
        plot(xhor, VAR.CI.SUP(:,jidx,iidx),'LineStyle','--','Color',optplot.Color)
        hold on
        plot(xhor, VAR.CI.INF(:,jidx,iidx),'LineStyle','--','Color',optplot.Color)
        title(['Responses of ' VAR.varnames{jidx} ' to ' VAR.varnames{iidx}]); 
    end
end

% screensize = get(0, 'Screensize');
% sc_hor = screensize(3);
% sc_ver = screensize(4);

% get(0, 'Screensize')
% f.Position(3:4) = [280 210];
% set(gcf, 'Position', get(0, 'Screensize'));

% 
% 
% %%
% for jj=pick:nshocks                
%     for ii=1:nvars
%         subplot(row,col,ii);
%         plot(steps,IR(:,ii,jj),'LineStyle','-','Color','k','LineWidth',2,'Marker',SwatheOpt.marker); hold on
%         if exist('INF','var') && exist('SUP','var')
%             PlotSwathe(IR(:,ii,jj),[INF(:,ii,jj) SUP(:,ii,jj)],SwatheOpt); hold on;
%         end
%         plot(x_axis,'--k','LineWidth',0.5); hold on
%         xlim([1 nsteps]);
%         title([vnames{ii} ' to ' snames{jj}], 'FontWeight','bold','FontSize',10); 
%         set(gca, 'Layer', 'top');
%     end
%     % Save
%     FigName = [filename num2str(jj)];
%     if quality 
%         if suptitle==1
%             Alphabet = char('a'+(1:nshocks)-1);
%             SupTitle([Alphabet(jj) ') IR to a shock to '  vnames{jj}])
%         end
%         set(gcf, 'Color', 'w');
%         export_fig(FigName,'-pdf','-painters')
%     else
%         print('-dpdf','-r100',FigName);
%     end
%     clf('reset');
% end

