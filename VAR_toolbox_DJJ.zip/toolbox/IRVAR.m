function VAR = IRVAR(VAR, optIR)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Return Impulse Responses, and
% Calculate confidence interval if optIR.CImethod~=None
% Possible optIR.CImethod : 
%       1. 'None'                       : Do not calculate CI
%       2. 'asymptotic'
%       3. 'bootstrap'
%       4. 'bootstrap-after-bootstrap'
%
% optIR.nboot is required, if optIR.CImethod='bootstrap'or'b-a-b' (default 1000)
% optIR.ortho = 1, if want orthogonalized impulse responses
%             = 0, if not
%
% VAR_LP_Toolkit Ver. 1.0
% Dong-jae Jung, Bank of Korea
% djjeong@bok.or.kr
% July. 2022
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if ~exist('optIR', 'var')
    optIR.CImethod = 'None';
end
CImethod = optIR.CImethod;

if (~strcmp(CImethod,'None')) && (~strcmp(CImethod,'asymptotic')) 
    if ~isfield(optIR, 'nboot')
        optIR.nboot = 1000;  % Default : 1,000 times of bootstrap
    end
end

if ~isfield(optIR, 'ortho')
    optIR.ortho = 1;     % Default : orthogonalized IR
end
Ortho = optIR.ortho;

if ~isfield(optIR, 'unitshock')
    optIR.unitshock = 0;     % Default : One SD shock
end

nvar = VAR.nvar;
nlags = VAR.nlags;

% %%% 1. IR
% if Ortho == 1
%     % if P given, use P as IR
%     if isfield(VAR, 'P')
%     elseif ~isfield(VAR, 'A') && ~isfield(VAR, 'B') % if all of P,A,B are not given, assume recursive ordering
%         [P, flag] = chol(VAR.Sigma, 'lower');
%         VAR.P = P;
%     else
%         if isfield(VAR, 'A') && ~isfield(VAR, 'B')
%             VAR.B = eye(VAR.nvar);
%         elseif ~isfield(VAR, 'A') && isfield(VAR, 'B')
%             VAR.A = eye(VAR.nvar);
%         end 
%         locA = isnan(VAR.A);  
%         locB = isnan(VAR.B);
%         if max(abs(VAR.A-eye(VAR.nvar)) +abs(locB-tril(ones(VAR.nvar,VAR.nvar))), [],'all' ) +max(abs(VAR.B(~locB)-VAR.B(~locB)*0), [],'all' ) < 0.0001   % If Given AB system is the B system for cholesky ordering
%             [P, flag] = chol(VAR.Sigma, 'lower');
%             VAR.P = P;
%         else
%             if isfield(VAR, 'LR') % for LR restriction
%                 Beta = VAR.Beta';
%                 LRM = eye(VAR.nvar);
%                 for ll =1:VAR.nlags
%                     LRM = LRM - Beta(:,(ll-1)*VAR.nvar+1:ll*VAR.nvar);
%                 end
%                 LRM = eye(VAR.nvar)/LRM;   % LR multiplier
%                 VAR.LRM = LRM;
%                 
% %                 locBmod = locB;
%                 locLR = isnan(VAR.LR);
%                 [row,col] = ind2sub(size(locLR), find(~locLR));
%                 freeB = zeros(size(row));
%                 for i = 1:length(row)
%                     freeBi = find(locB(:,col(i)));
%                     freeB(i) = freeBi(1);     % replace B(freeBi, coli) according to the LR constraint
%                     locB(freeB(i),col(i)) = 0;
%                 end
%                 VAR.LRloc = [row,col,freeB];
%             end
% 
%             VAR.locA = locA; VAR.locB = locB;
%             NparaA = sum(locA,'all'); NparaB = sum(locB,'all');  VAR.NparaA = NparaA; VAR.NparaB = NparaB;            
%             
%             para = ones(NparaA+NparaB,1);
%             warning('off','MATLAB:singularMatrix')
% %             LogLikelihoodVAR(para, VAR);
%             fnLL = @(x) -1*LogLikelihoodVAR(x, VAR);
%             options = optimoptions(@fminunc,'Display','notify-detailed','Algorithm','quasi-newton');
%             [para,fval,exitflag,output] = fminunc(fnLL,para,options);
%     %         options = optimset('Display','iter');
%     %         [x2,fval,exitflag,output] = fminsearch(fnLL,para,options); 
%             warning('on','MATLAB:singularMatrix')
%             paraA = para(1:NparaA);
%             paraB = para(NparaA+1:NparaA+NparaB);
%             Ahat = VAR.A; Ahat(locA)=paraA;  
%             Bhat = VAR.B; Bhat(locB)=paraB;
%             if isfield(VAR, 'LR')   % for LR restriction
%                 uniquecol = unique(col);
%                 Nequ = length(uniquecol);                
%                 for ci = 1:Nequ
%                     coli = uniquecol(ci); iidx = (col==coli); rowi = row(iidx); freeBi = freeB(iidx); nonfreeBi = setdiff(1:size(locB,1), freeBi);
%                     Bhat(freeBi,coli) = LRM(rowi,freeBi)\(VAR.LR(rowi, coli) - LRM(rowi,nonfreeBi)*Bhat(nonfreeBi,coli));
%                 end
% %                 for i = 1:length(row)
% %                     rowi = row(i); coli = col(i); freeBi = freeB(i);
% %                     Bhat(freeBi,coli) = (LRM(rowi,setdiff(1:end,freeBi))*Bhat(setdiff(1:end,freeBi),coli) - VAR.LR(rowi, coli))/(-LRM(rowi,freeBi));
% %                 end
%             end
%             
%             Ahat = Ahat*diag(sign(diag(Ahat))); 
%             Bhat = Bhat*diag(sign(diag(Bhat)));   
%             VAR.Ahat = Ahat; VAR.Bhat = Bhat;
%             VAR.P = Ahat\Bhat;
%         end
%     end
%     Pnorm = VAR.P/diag(diag(VAR.P));
%     VAR.Pnorm = Pnorm;  % Normalization
%     if optIR.unitshock
%         PP = VAR.P;
%     else
%         PP = VAR.Pnorm;
%     end
% elseif Ortho ==0
%     if optIR.unitshock
%         PP = eye(nvar,nvar);
%     else
%         PP = diag(sqrt(diag(VAR.Sigma)));
%     end
% else
%     error('optIR.ortho must be 1 or 0')
% end
if Ortho == 1
    if optIR.unitshock
        if ~isfield(VAR, 'Pnorm')
            VAR.Pnorm = VAR.P/diag(diag(VAR.P));
        end
        PP = VAR.Pnorm;
    else
        PP = VAR.P;
    end
elseif Ortho ==0
    if optIR.unitshock
        PP = eye(nvar,nvar);
    else
        PP = diag(sqrt(diag(VAR.Sigma)));
    end
else
    error('optCI.ortho must be 1 or 0')
end

% IR
IR = zeros(optIR.IRhor, nvar, nvar);

EE = [eye(nvar) ; zeros(nvar*(nlags-1), nvar)];
IR(1,:,:) = PP;

PSI = eye(size(VAR.Comp));
for h = 2:optIR.IRhor
    PSI = VAR.Comp*PSI;
    IR(h,:,:) = EE'*PSI*EE*PP;
end


%%% 2. Confidence Interval
switch CImethod
    case {'asymptotic'}        
        Sigma_beta = kron(diag(diag(VAR.Sigma)), inv(VAR.X'*VAR.X));
        IR_SIGMA = zeros(optIR.IRhor, nvar*nvar, nvar*nvar);
        IR_SE = zeros(optIR.IRhor, nvar, nvar);
        nadd = VAR.Nexo+VAR.Ntrend;
        BigComp = [VAR.Beta(1:VAR.nvar*VAR.nlags+nadd,:)'; eye(VAR.nvar*(VAR.nlags-1)) zeros(VAR.nvar*(VAR.nlags-1),VAR.nvar+nadd) ; zeros(nadd, VAR.Nx)];
        BigEE = [eye(nvar) ; zeros(nvar*(nlags-1)+nadd, nvar)];
        for h = 2:optIR.IRhor
            G = zeros(VAR.Nx*nvar, nvar*nvar);
            for m = 0:h-2
                G = G + kron((BigComp^(h-2-m)*BigEE), squeeze(IR(m+1,:,:))');
            end
            IR_SIGMAh  = (G'*Sigma_beta*G)./VAR.T;
            IR_SE(h, :,:) = reshape(sqrt(diag(IR_SIGMAh)), nvar,nvar);
        end

        CIlevel_half = (100-optIR.CIlevel)/100/2;
        modi = norminv(CIlevel_half, 0, IR_SE);
        modi(1,:,:) = 0;
        VAR.CI.INF = IR + modi;
        VAR.CI.SUP = IR - modi;
        VAR.CI.SE = IR_SE;
    case {'bootstrap', 'bootstrap-after-bootstrap'}
        nboot = optIR.nboot;
        IRboot = zeros(nboot, optIR.IRhor, nvar, nvar);
        BETAboot = zeros([nboot, size(VAR.Beta)]);
        BETAori = VAR.Beta;
        res = VAR.Y - VAR.X*BETAori;

        VARi = VAR;
        optCIi = optIR; optCIi.CImethod='None';
        i=1; j=1;
        while i<=nboot
        %     i
            ui = res(ceil(size(res,1)*rand(VAR.T,1)),:);

            YY = zeros(size(VAR.Y));
            XX = VAR.X;
            for t = 1:VAR.T
            % for t = 1:3
                ytmp = XX(t,:)*VAR.Beta + ui(t,:);
                YY(t,:) = ytmp;
                if t<VAR.T
                    XX(t+1, 1:VAR.nvar*(VAR.nlags)) = [ytmp XX(t, 1:VAR.nvar*(VAR.nlags-1))];
                end
            end

            VARi.X = XX; VARi.Y = YY; 
            VARi = reducedVAR(VARi);

            if strcmp(CImethod,'bootstrap')
                if VARi.maxEig <1
%                     IRi = VAR_IR(VARi);  
                    VARi = ImpulseResponse(VARi, optCIi);
                    IRboot(i,:,:,:) = VARi.IR;
                    i = i+1;
                end
                j=j+1;
                if j>nboot*2
                    disp('END Bootstrapping')
                    disp('Too many non-converging trials')
                    break
                end
            elseif strcmp(CImethod,'bootstrap-after-bootstrap')
        %         IRi = VAR_IR(VARi);
        %         IRboot(i,:,:,:) = IRi;
                BETAboot(i,:,:) = VARi.Beta;
                i = i+1;
            end

        end

        % Bootstrap-after-bootstrap, bias corrected CI (Kilian 1998)
        if strcmp(CImethod,'bootstrap-after-bootstrap')
            BETAbias = squeeze(mean(BETAboot, 1)) - BETAori;
            BETAcorrected = BETAori - BETAbias;
            VARstep2 = VAR;
            delta=1;            

            if ~isfield(optIR, 'nboot2step')
                optIR.nboot2step = nboot*2;     % Default : 1stage nboot * 2
            end
            if ~isfield(optIR, 'deltastep')
                optIR.deltastep = 0.01;     % Default : 1stage nboot * 2
            end
            deltastep = optIR.deltastep;
            
            optCI_2step = optIR;
            optCI_2step.CImethod = 'bootstrap';
            optCI_2step.nboot = optIR.nboot2step;

            VARstep2.Comp = [VARstep2.Beta(1:VAR.nvar*VAR.nlags,:)'; eye(VAR.nvar*(VAR.nlags-1)) zeros(VAR.nvar*(VAR.nlags-1),VAR.nvar)];
            VARstep2.maxEig = max(abs(eig(VARstep2.Comp)));
            if VARstep2.maxEig >=1
                maxEigtmp = VARstep2.maxEig;
                while maxEigtmp>=1
                    delta = delta - deltastep;
                    BETAcorrected = BETAori - delta*BETAbias;
                    Comptmp = [BETAcorrected(1:VAR.nvar*VAR.nlags,:)'; eye(VAR.nvar*(VAR.nlags-1)) zeros(VAR.nvar*(VAR.nlags-1),VAR.nvar)];
                    maxEigtmp = max(abs(eig(Comptmp)));
                end    
            end
            VARstep2.Beta = BETAcorrected;
            VARstep2 = ImpulseResponse(VARstep2, optCI_2step);
            VAR.CI = VARstep2.CI;
            VAR.IRboot = VARstep2.IRboot;

        elseif strcmp(CImethod,'bootstrap')
            cl = round((100-optIR.CIlevel)/2);
            VAR.CI.INF = squeeze(prctile(IRboot, cl));
            VAR.CI.SUP = squeeze(prctile(IRboot, 100-cl));
            VAR.CI.MED = squeeze(prctile(IRboot, 50));
            VAR.CI.MEAN = squeeze(mean(IRboot, 1));
            VAR.IRboot = IRboot;
        end

%         VAR.nboot = nboot;
end

% 3. return
VAR.IR = IR;
VAR.optIR = optIR;
end