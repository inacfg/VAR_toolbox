function VAR = reducedVAR(VAR)

VAR.Beta = VAR.X\VAR.Y;
VAR.res = VAR.Y - VAR.X*VAR.Beta;
VAR.SSE = (VAR.res'*VAR.res);
VAR.Sigma = (VAR.res'*VAR.res)./(VAR.T - VAR.Nx);
VAR.beta = VAR.Beta(:);

VAR.Comp = [VAR.Beta(1:VAR.nvar*VAR.nlags,:)'; eye(VAR.nvar*(VAR.nlags-1)) zeros(VAR.nvar*(VAR.nlags-1),VAR.nvar)];
VAR.maxEig = max(abs(eig(VAR.Comp)));

end
