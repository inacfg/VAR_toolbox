%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sample code
% Dong-jae Jung, djjeong@bok.or.kr
% July. 2022
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

addpath('toolbox')
clear all; 
%% Data Input as table
DATraw = load('Datraw.mat').DATraw;
[DAT, dateval, Model] = makeDAT(DATraw, [], [], [], [], []);

%% Construct Model
Model.nlags     = 2;   % number of lags
Model.trend     = 1;   % 1: constance, 2:linear trend, 3: quadratic trend

Model = makeVAR(DAT, Model);
%% Reduced Model
Model = reducedVAR(Model);

%% Structural
[Pchol, flag] = chol(Model.Sigma, 'lower');
% Option for VAR
optIR.IRhor     = 11;          
optIR.unitshock = 0;   % 1 : one unit shock, else: one SD shock
optIR.ortho = 1*1;
optIR.CImethod = 'bootstrap';
optIR.CImethod = 'bootstrap-after-bootstrap';
optIR.nboot = 1000;
optIR.CIlevel = 90;

% (1) Short-run restriction with recursive ordering. To to this, giving none of P,A,B, or proper A and B matrices.
VAR1 = Model; 
VAR1 = ImpulseResponse(VAR1, optIR);
% (1.1) asyptotic CI
optIR.CImethod = 'asymtotic';
VAR11 = ImpulseResponse(Model, optIR);

% (2) Short-run restriction with recursive ordering with B system
VAR2 = Model; 
VAR2.B = NaN(Model.nvar, Model.nvar);
VAR2.B = tril(VAR2.B);
optIR.CImethod = 'bootstrap';
VAR2 = ImpulseResponse(VAR2, optIR);

% (3) Non-recursive restriction
VAR3 = Model; 
VAR3.A = eye(VAR3.nvar);
VAR3.B = NaN(VAR3.nvar, VAR3.nvar);
VAR3.B = triu(VAR3.B);
VAR3 = ImpulseResponse(VAR3, optIR);


% (4) Mix long-run and short-run restriction
VAR4 = Model; 
VAR4.A = eye(VAR4.nvar);
VAR4.B = NaN(VAR4.nvar, VAR4.nvar);
VAR4.B = tril(VAR4.B);
VAR4.B(2:3,4) = NaN; 
VAR4.LR = NaN(VAR4.nvar, VAR4.nvar);
VAR4.LR(2:3,4) = 0;

VAR4 = ImpulseResponse(VAR4, optIR);

% (5) instrument variable by Gertler & Karadi(2015)
% Instrumented variable should be ordered at first
varnamesX = {'Call','GDP','CPI','L'};
tcodeX = [0,2,2,2];
varnamesExo = {'CRISIS'};
tcodeExo = [0];
[DAT5, dateval5, VAR5] = makeDAT(DATraw, datevalraw, varnamesX, tcodeX, varnamesExo, tcodeExo);
VAR5.nlags     = 2;   % number of lags
VAR5.trend     = 1;   % 1: constance, 2:linear trend, 3: quadratic trend

VAR5 = makeVAR(DAT5, VAR5);
VAR5 = reducedVAR(VAR5);
VAR5.Z = VAR5.Y(:,1);
VAR5 = instrumentGK(VAR5);
VAR5 = ImpulseResponse(VAR5, optIR);

% (6) Local Projection
LP = Model;
optIR.SEtype = 'spherical';
optIR.SEtype = 'HAC';
LP.IRmethod = 'LP';
LP = ImpulseResponse(LP, optIR);

% (8) Baysian VAR
optIR.nsave = 10000;        % Final number of draws to save
optIR.nburn = 2000;         % Draws to discard (burn-in)
optIR.P_uncertainty = 1;    % 1 if you want to jointly consider uncertainty associated structural identication parameters
optIR.prior = 4;
BVAR = Model;
BVAR.IRmethod = 'BVAR';
BVAR = ImpulseResponse(BVAR, optIR);

% (9) Sign Restriction by Baysian VAR  _ Pure SR approach(Default)
optIR.ndraw = 200;        % Final number of draws to save
optIR.nburn = 2000;         % Draws to discard (burn-in)
optIR.nrotate = 200;        % Number of rotate
optIR.prior = 4;
BVARSIGN = Model;
BVARSIGN.IRmethod = 'BVAR_SIGN';
BVARSIGN.SIGN = zeros(BVARSIGN.IRhor, BVARSIGN.nvar, BVARSIGN.nvar);
BVARSIGN.SIGN(1:2, 1:2, 4) = -1;  % MP shock to GDP & INF negative for 2 periods (periods, nvar, nshock)
BVARSIGN.SIGN(1:2, 4, 4) = 1;  % MP shock to GDP & INF negative for 2 periods
BVARSIGN = IRBVAR_SIGN(BVARSIGN, optIR);

% (9-1) Sign Restriction by Baysian VAR  _ Penalty approach
optIRSR = optIR;
optIRSR.SRmethod = 'Penalty';
BVARSIGN2 = Model;
BVARSIGN2.IRmethod = 'BVAR_SIGN';
BVARSIGN2.SIGN = zeros(BVARSIGN2.IRhor, BVARSIGN2.nvar, BVARSIGN2.nvar);
BVARSIGN2.SIGN(1:2, 1:2, 4) = -1;  % MP shock to GDP & INF negative for 2 periods
BVARSIGN2.SIGN(1:2, 4, 4) = 1;  % MP shock to GDP & INF negative for 2 periods
BVARSIGN2 = IRBVAR_SIGN(BVARSIGN2, optIRSR);


% Plot
close all
optPlot.newfig = 1;
shockvar = {'Call'};
resvar = {'GDP','CPI','Call'};
plotIR(VAR1, shockvar, resvar, optPlot)
plotIR(VAR2, shockvar, resvar, optPlot)
plotIR(VAR3, shockvar, resvar, optPlot)
plotIR(VAR4, shockvar, resvar, optPlot)
plotIR(LP, shockvar, resvar, optPlot)
plotIR(BVAR, shockvar, resvar, optPlot)
plotIR(BVARSIGN, shockvar, resvar, optPlot)
plotIR(BVARSIGN2, shockvar, resvar, optPlot)

% FEVD
VAR1 = fevd(VAR1);
BVARSIGN2 = fevd(BVARSIGN2);

% HD
VAR1 = hd(VAR1, optIR);

optPlot.Stochastic = 1;  % 0 if decomposition of all the parts including deterministic parts
plotHD(VAR1, 'GDP', [], optPlot)
plotHD(VAR1, 'GDP', 'Call', optPlot)

% Forecasting
VAR1 = forecastVAR(VAR1, 24, VAR1.T-5, [],1);